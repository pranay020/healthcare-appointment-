from .patient import Patient
from .allergy import Allergy
from .emergency_contact import Emergency_Contact
from .specialization import Specialization
from .doctor import Doctor
from .appointment import Appointment