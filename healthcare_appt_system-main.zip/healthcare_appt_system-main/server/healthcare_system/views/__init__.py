from .patient import PatientView
from .doctor import DoctorView
from .specialization import SpecializationView
from .emergency_contact import EmergencyContactView
from .allergy import AllergyView
from .appointment import AppointmentView