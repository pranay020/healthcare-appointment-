# Healthcare System (Client) <!-- omit in toc -->

## Table of Contents <!-- omit in toc -->
- [Setup ](#setup-)
- [Support ](#support-)

## Setup <a id="setup"></a>
1. Install app dependencies
```
$ npm install
```
or
```
$ yarn install
```

2. Start the development server
```
$ npm start
```
or
```
$ yarn start
```

## Support <a id="support"></a>
* [React](https://react.dev/)
* [Ant Design](https://ant.design/)
